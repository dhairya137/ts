import * as cdk from 'aws-cdk-lib';
import { DynamoDBStack } from './dynamodb-stack';
interface LambdaStackProps extends cdk.StackProps {
    dynamoDbStack: DynamoDBStack;
}
export declare class LambdaStack extends cdk.Stack {
    constructor(scope: cdk.App, id: string, props: LambdaStackProps);
}
export {};
