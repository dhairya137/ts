import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as path from 'path';
import { DynamoDBStack } from './dynamodb-stack';

interface LambdaStackProps extends cdk.StackProps {
  dynamoDbStack: DynamoDBStack;
}

export class LambdaStack extends cdk.Stack {
    constructor(scope: cdk.App, id: string, props: LambdaStackProps) {
    super(scope, id, props);

    const getLambda = new lambda.Function(this, 'GetLambdaHandler', {
      runtime: lambda.Runtime.NODEJS_14_X,
      handler: 'get.handler',
      code: lambda.Code.fromAsset(path.join(__dirname, '..', 'lambda', 'get')),
      environment: {
        TABLE_NAME: props.dynamoDbStack.table.tableName,
      },
    });

    const postLambda = new lambda.Function(this, 'PostLambdaHandler', {
      runtime: lambda.Runtime.NODEJS_14_X,
      handler: 'post.handler',
      code: lambda.Code.fromAsset(path.join(__dirname, '..', 'lambda', 'post')),
      environment: {
        TABLE_NAME: props.dynamoDbStack.table.tableName,
      },
    });

    props.dynamoDbStack.table.grantReadWriteData(getLambda);
    props.dynamoDbStack.table.grantReadWriteData(postLambda);

    const api = new apigateway.RestApi(this, 'ItemsApi', {
      restApiName: 'Items Service',
    });

    const items = api.root.addResource('items');
    items.addMethod('GET', new apigateway.LambdaIntegration(getLambda), {
      authorizationType: apigateway.AuthorizationType.NONE,
    });

    const singleItem = items.addResource('{id}');
    singleItem.addMethod('GET', new apigateway.LambdaIntegration(getLambda), {
      authorizationType: apigateway.AuthorizationType.NONE,
    });

    items.addMethod('POST', new apigateway.LambdaIntegration(postLambda), {
      authorizationType: apigateway.AuthorizationType.NONE,
    });
  }
}

