import * as cdk from 'aws-cdk-lib';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as constructs from 'constructs';
export declare class DynamoDBStack extends cdk.Stack {
    readonly table: dynamodb.Table;
    constructor(scope: constructs.Construct, id: string, props?: cdk.StackProps);
}
