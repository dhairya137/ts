export {};

const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

exports.handler = async function(event: any) {
  console.log("request:", JSON.stringify(event, undefined, 2));

  const params = {
    Key: {
      id: event.pathParameters.id,
    },
    TableName: process.env.TABLE_NAME, // provided by CloudFormation
  };

  const result = await dynamoDb.scan(params).promise();

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(result.Items),
  };
};

