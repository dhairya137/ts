export {};

const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

exports.handler = async function(event: any) {
  console.log("request:", JSON.stringify(event, undefined, 2));
  const timestamp = new Date().getTime();
  const data = JSON.parse(event.body);

  const params = {
    TableName: process.env.TABLE_NAME, // provided by CloudFormation
    Item: {
      id: data.id,
      name: data.name,
      age: data.age,
      timestamp: timestamp,
    },
  };

  await dynamoDb.put(params).promise();

  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params.Item),
  };
};

