import express, { Request, Response } from 'express';
import AWS from 'aws-sdk';

// Configure AWS SDK
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});

const app = express();
app.use(express.json());

const dynamodb = new AWS.DynamoDB.DocumentClient();

const TABLE_NAME = process.env.DYNAMODB_TABLE_NAME || '';

app.get('/:id', (req: Request, res: Response) => {
    const params = {
        TableName: TABLE_NAME,
        Key: {
            id: req.params.id
        }
    };
    dynamodb.get(params, (err, data) => {
        if (err) {
            console.error("Unable to retrieve data. Error JSON:", JSON.stringify(err, null, 2));
            res.status(500).json({ error: 'Could not retrieve data' });
        } else {
            res.json(data.Item);
        }
    });
});

app.post('/', (req: Request, res: Response) => {
    const params = {
        TableName: TABLE_NAME,
        Item: {
            id: req.body.id,
            type: req.body.type,
            height: req.body.height
        }
    };
    dynamodb.put(params, (err, data) => {
        if (err) {
            console.error("Unable to add data. Error JSON:", JSON.stringify(err, null, 2));
            res.status(500).json({ error: 'Could not create data' });
        } else {
            res.json({ id: req.body.id });
        }
    });
});

app.listen(8080, () => {
    console.log('Server is running at http://localhost:8080');
});

export default app;

