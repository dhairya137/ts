import * as cdk from '@aws-cdk/core';
import * as ecs from '@aws-cdk/aws-ecs';
import * as ecs_patterns from '@aws-cdk/aws-ecs-patterns';
import * as dynamodb from '@aws-cdk/aws-dynamodb';
import * as ec2 from '@aws-cdk/aws-ec2';
import * as secretsmanager from '@aws-cdk/aws-secretsmanager';
import * as iam from '@aws-cdk/aws-iam';
import * as ecr from '@aws-cdk/aws-ecr';
import * as elbv2 from '@aws-cdk/aws-elasticloadbalancingv2';

import * as dotenv from 'dotenv';
dotenv.config();

export class MyProjectStack extends cdk.Stack {
  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Create a new VPC
    //const vpc = new ec2.Vpc(this, 'MyVpc', { maxAzs: 2 });

    // Use existing vpc
    const vpcId = 'vpc-017016f4b94dc4f08';
    const vpc = ec2.Vpc.fromLookup(this, 'MyVpc', { vpcId });

    // Create a new DynamoDB table
    const table = new dynamodb.Table(this, 'Table', {
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      tableName: 'Trees',
      removalPolicy: cdk.RemovalPolicy.DESTROY // NOT recommended for production code
    });

    new cdk.CfnOutput(this, 'TableName', { value: table.tableName });

    // Create a secret in Secrets Manager
    const secret = new secretsmanager.Secret(this, 'MySecret', {
  secretName: 'MySecret',
  generateSecretString: {
    secretStringTemplate: JSON.stringify({
      AWS_ACCESS_KEY_ID: process.env.AWS_ACCESS_KEY_ID,
      AWS_SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY,
      DYNAMODB_TABLE_NAME: table.tableName
    }),
 generateStringKey: 'password',
  },
});

    const taskExecutionRole = new iam.Role(this, 'TaskExecutionRole', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
    });

    taskExecutionRole.addToPolicy(
      new iam.PolicyStatement({
         actions: ['ecr:GetAuthorizationToken'],
         resources: ['*'],
      })
    );

    secret.grantRead(taskExecutionRole);


 // Create a managed policy
const fullAccessToECRPolicy = new iam.ManagedPolicy(this, 'FullAccessToECR', {
  statements: [
    new iam.PolicyStatement({
      actions: ['ecr:*'],
      resources: ['*']
    })
  ]
});

    // Create an ECS cluster
    const cluster = new ecs.Cluster(this, 'Cluster', { vpc });

    // Create an ECS service
    const ecsService = new ecs_patterns.ApplicationLoadBalancedFargateService(this, 'Service', {
      cluster,
      cpu: 256,
      desiredCount: 1,
      taskImageOptions: {
        image: ecs.ContainerImage.fromRegistry("571653956102.dkr.ecr.ap-south-1.amazonaws.com/demo:latest"),
        containerPort: 8080,
        environment: {
          AWS_REGION: this.region
        },
        secrets: {
          AWS_ACCESS_KEY_ID: ecs.Secret.fromSecretsManager(secret, 'AWS_ACCESS_KEY_ID'),
          AWS_SECRET_ACCESS_KEY: ecs.Secret.fromSecretsManager(secret, 'AWS_SECRET_ACCESS_KEY'),
          DYNAMODB_TABLE_NAME: ecs.Secret.fromSecretsManager(secret, 'DYNAMODB_TABLE_NAME'),
        },
      },
      memoryLimitMiB: 512,
      publicLoadBalancer: true
    });

    // Update the default listener configuration
    const listener = ecsService.loadBalancer.addListener('Listener8080', {
  port: 8080,
});

taskExecutionRole.addManagedPolicy(fullAccessToECRPolicy);

// Associate the target group with the new listener
listener.addTargets('TargetGroup8080', {
  port: 8080,
  targets: [ecsService.service],
  protocol: elbv2.ApplicationProtocol.HTTP,
});

    // Grant the ECS task role read/write permissions to the DynamoDB table
    table.grantReadWriteData(ecsService.taskDefinition.taskRole);
  }
}

