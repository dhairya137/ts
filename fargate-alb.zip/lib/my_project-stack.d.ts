import * as cdk from '@aws-cdk/core';
export declare class MyProjectStack extends cdk.Stack {
    constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps);
}
