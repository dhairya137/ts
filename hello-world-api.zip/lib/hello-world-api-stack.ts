import * as cdk from '@aws-cdk/core';
import * as lambda from '@aws-cdk/aws-lambda';
import * as apigateway from '@aws-cdk/aws-apigateway';

export class HelloWorldStack extends cdk.Stack {
  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Defines AWS Lambda resource
    const helloWorldLambda = new lambda.Function(this, 'HelloWorldLambda', {
      runtime: lambda.Runtime.NODEJS_14_X,    
      code: lambda.Code.fromAsset('lambda'),  
      handler: 'hello.handler',               
    });

    // Defines an API Gateway REST API resource backed by our "helloWorldLambda" function.
    new apigateway.LambdaRestApi(this, 'Endpoint', {
      handler: helloWorldLambda,
    });
  }
}

