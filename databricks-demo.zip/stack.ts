import {Construct} from "constructs";
import {Stack, StackProps} from "aws-cdk-lib";
import {DatabricksCluster} from "databricks-cdk";

export class SimpleStack extends Stack {
  constructor(scope: Construct, id: string, props: StackProps) {
    super(scope, id, props);

    // Deploy the cluster to AWS.
    this.deploy(new DatabricksCluster(this, "MyCluster"));
  }

  // Define the deploy method.
  deploy(cluster: DatabricksCluster) {
    // Deploy the cluster to AWS.
    cluster.deploy();
  }
}
